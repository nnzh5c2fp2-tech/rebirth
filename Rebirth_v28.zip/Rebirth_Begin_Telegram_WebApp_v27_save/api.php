<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'config.php is missing']); exit;
}
$config = require $configFile;

try {
    $db = $config['db'];
    $pdo = new PDO(
        "mysql:host={$db['host']};dbname={$db['name']};charset={$db['charset']}",
        $db['user'], $db['pass'],
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'Database connection failed']); exit;
}

function out($data, $status=200){ http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function body(){ $raw=file_get_contents('php://input'); $x=json_decode($raw,true); return is_array($x)?$x:$_POST; }
function tgUser($initData, $botToken){
    if (!$initData) return null;
    parse_str($initData, $data);
    $hash=$data['hash']??'';
    if (!$hash) return null;
    unset($data['hash']); unset($data['signature']);
    ksort($data);
    $pairs=[]; foreach($data as $k=>$v) $pairs[]=$k.'='.$v;
    $check=implode("\n",$pairs);
    $secret=hash_hmac('sha256',$botToken,'WebAppData',true);
    $calc=hash_hmac('sha256',$check,$secret);
    if (!hash_equals($calc,$hash)) return null;
    $auth=(int)($data['auth_date']??0);
    if (!$auth || abs(time()-$auth)>86400) return null;
    $user=json_decode($data['user']??'',true);
    return is_array($user)&&!empty($user['id'])?$user:null;
}

$input=body();
$initData=(string)($input['initData']??$_SERVER['HTTP_X_TELEGRAM_INIT_DATA']??'');
$user=tgUser($initData,$config['telegram_bot_token']);
if (!$user) out(['ok'=>false,'error'=>'Telegram authorization failed'],401);

$uid=(string)$user['id'];
$name=trim(($user['first_name']??'').' '.($user['last_name']??''));
$name=$name!==''?$name:('Игрок '.$uid);
$username=$user['username']??null;
$action=(string)($input['action']??'');

function playerRow($pdo,$uid){
    $q=$pdo->prepare('SELECT * FROM players WHERE telegram_id=?'); $q->execute([$uid]); return $q->fetch()?:null;
}
function ensurePlayer($pdo,$uid,$name,$username){
    $row=playerRow($pdo,$uid);
    if(!$row){
        $stmt=$pdo->prepare('INSERT INTO players(telegram_id,username,display_name,state_json) VALUES(?,?,?,?)');
        $stmt->execute([$uid,$username,$name,json_encode(['_saveVersion'=>27,'_savedAt'=>time()*1000],JSON_UNESCAPED_UNICODE)]);
        return playerRow($pdo,$uid);
    }
    $stmt=$pdo->prepare('UPDATE players SET username=?,display_name=? WHERE telegram_id=?'); $stmt->execute([$username,$name,$uid]);
    return playerRow($pdo,$uid);
}

ensurePlayer($pdo,$uid,$name,$username);

if($action==='load'){
    $row=playerRow($pdo,$uid);
    $state=json_decode($row['state_json'],true);
    out(['ok'=>true,'state'=>$state?:null,'serverSavedAt'=>$row['updated_at']]);
}

if($action==='create_premium_invoice'){
    $payload='premium_'.$uid.'_'.bin2hex(random_bytes(8));
    $botToken=$config['telegram_bot_token'];
    $url='https://api.telegram.org/bot'.rawurlencode($botToken).'/createInvoiceLink';
    $post=[
      'title'=>'Premium',
      'description'=>'Premium для игры «Перерождение: Начало»',
      'payload'=>$payload,
      'currency'=>'XTR',
      'prices'=>json_encode([['label'=>'Premium','amount'=>100]],JSON_UNESCAPED_UNICODE)
    ];
    $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_POSTFIELDS=>$post,CURLOPT_TIMEOUT=>15]);
    $raw=curl_exec($ch); $err=curl_error($ch); curl_close($ch);
    if($raw===false) out(['ok'=>false,'error'=>'Telegram API unavailable'],502);
    $res=json_decode($raw,true);
    if(empty($res['ok'])||empty($res['result'])) out(['ok'=>false,'error'=>'Invoice creation failed','details'=>$res['description']??$err],502);
    out(['ok'=>true,'invoiceLink'=>$res['result']]);
}

if($action==='save'){
    $state=$input['state']??null;
    if(!is_array($state)) out(['ok'=>false,'error'=>'Invalid state'],400);
    $state['_savedAt']=max((int)($state['_savedAt']??0),time()*1000);
    $level=(int)($state['level']??1);
    $power=(int)($state['power']??0);
    if(!$power){
        $power=(int)($state['atk']??0)+((int)($state['maxHp']??0)*0.22)+((int)($state['def']??0)*2)+((int)($state['spentStats']['strength']??0)+(int)($state['statPoints']??0))*2.2+((int)($state['crit']??0)*2);
    }
    $rating=(int)($state['arenaRating']??1000);
    $json=json_encode($state,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $stmt=$pdo->prepare('UPDATE players SET username=?,display_name=?,state_json=?,level=?,power=?,arena_rating=? WHERE telegram_id=?');
    $stmt->execute([$username,$name,$json,$level,$power,$rating,$uid]);
    // Keep the public bazaar mirror in sync with the seller's five local lots.
    $pdo->beginTransaction();
    try{
        $del=$pdo->prepare('DELETE FROM bazaar_lots WHERE seller_id=?'); $del->execute([$uid]);
        $lots=$state['bazaarLots']??[];
        if(is_array($lots)){
            $ins=$pdo->prepare('INSERT INTO bazaar_lots(id,seller_id,seller_name,item_json,price,created_at) VALUES(?,?,?,?,?,FROM_UNIXTIME(?))');
            foreach(array_slice($lots,0,5) as $lot){
                if(empty($lot['id'])||empty($lot['item'])) continue;
                $ins->execute([(string)$lot['id'],$uid,$name,json_encode($lot['item'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),max(1,(int)($lot['price']??1)),max(0,(int)(($lot['createdAt']??time()*1000)/1000))]);
            }
        }
        $pdo->commit();
    }catch(Throwable $e){$pdo->rollBack();}
    out(['ok'=>true,'savedAt'=>$state['_savedAt']]);
}

if($action==='chat_list'){
    $limit=min(100,max(10,(int)($input['limit']??50)));
    $q=$pdo->query('SELECT id,telegram_id,display_name,message,created_at FROM chat_messages ORDER BY id DESC LIMIT '.$limit);
    $rows=array_reverse($q->fetchAll()); out(['ok'=>true,'messages'=>$rows]);
}
if($action==='chat_send'){
    $msg=trim((string)($input['message']??''));
    $max=(int)($config['chat_max_length']??300);
    if($msg==='') out(['ok'=>false,'error'=>'Пустое сообщение'],400);
    if(mb_strlen($msg)>$max) $msg=mb_substr($msg,0,$max);
    $stmt=$pdo->prepare('INSERT INTO chat_messages(telegram_id,display_name,message) VALUES(?,?,?)');
    $stmt->execute([$uid,$name,$msg]);
    $pdo->exec('DELETE FROM chat_messages WHERE id < (SELECT id FROM (SELECT id FROM chat_messages ORDER BY id DESC LIMIT 1 OFFSET 499) x)');
    out(['ok'=>true]);
}

if($action==='bazaar_buy'){
    $lotId=(string)($input['lotId']??'');
    if($lotId==='') out(['ok'=>false,'error'=>'Lot not found'],400);
    try{
      $pdo->beginTransaction();
      $q=$pdo->prepare('SELECT * FROM bazaar_lots WHERE id=? FOR UPDATE'); $q->execute([$lotId]); $lot=$q->fetch();
      if(!$lot) throw new Exception('Lot no longer exists');
      if((string)$lot['seller_id']===$uid) throw new Exception('Cannot buy your own lot');
      $sellerId=(string)$lot['seller_id'];
      $buyer=$pdo->prepare('SELECT state_json FROM players WHERE telegram_id=? FOR UPDATE'); $buyer->execute([$uid]); $br=$buyer->fetch();
      $seller=$pdo->prepare('SELECT state_json FROM players WHERE telegram_id=? FOR UPDATE'); $seller->execute([$sellerId]); $sr=$seller->fetch();
      if(!$br||!$sr) throw new Exception('Player not found');
      $bs=json_decode($br['state_json'],true)?:[]; $ss=json_decode($sr['state_json'],true)?:[]; $price=(int)$lot['price'];
      if((int)($bs['coins']??0)<$price) throw new Exception('Недостаточно золота');
      $item=json_decode($lot['item_json'],true); if(!is_array($item)) throw new Exception('Invalid item');
      $bs['coins']=(int)$bs['coins']-$price; $bs['inventory']=array_values($bs['inventory']??[]); $bs['inventory'][]=$item;
      $ss['coins']=(int)($ss['coins']??0)+$price; $ss['bazaarLots']=array_values(array_filter($ss['bazaarLots']??[],fn($x)=>(string)($x['id']??'')!==$lotId));
      $bs['_savedAt']=time()*1000; $ss['_savedAt']=time()*1000;
      $up=$pdo->prepare('UPDATE players SET state_json=?,updated_at=CURRENT_TIMESTAMP WHERE telegram_id=?');
      $up->execute([json_encode($bs,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$uid]);
      $up->execute([json_encode($ss,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$sellerId]);
      $del=$pdo->prepare('DELETE FROM bazaar_lots WHERE id=?'); $del->execute([$lotId]);
      $pdo->commit(); out(['ok'=>true,'state'=>$bs]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();out(['ok'=>false,'error'=>$e->getMessage()],400);}
}

if($action==='rating'){
    $limit=min(100,max(10,(int)($input['limit']??50)));
    $q=$pdo->query('SELECT telegram_id,username,display_name,level,power,arena_rating FROM players ORDER BY power DESC, level DESC, telegram_id ASC LIMIT '.$limit);
    out(['ok'=>true,'players'=>$q->fetchAll()]);
}
if($action==='arena'){
    $limit=min(30,max(5,(int)($input['limit']??12)));
    $stmt=$pdo->prepare('SELECT telegram_id,username,display_name,level,power,arena_rating,state_json FROM players WHERE telegram_id<>? ORDER BY ABS(arena_rating-?) ASC, power DESC LIMIT '.$limit);
    $me=playerRow($pdo,$uid); $stmt->execute([$uid,(int)$me['arena_rating']]); $rows=$stmt->fetchAll();
    foreach($rows as &$r){$s=json_decode($r['state_json'],true)?:[]; $r['classKey']=$s['playerClass']??'assassin'; unset($r['state_json']);}
    out(['ok'=>true,'opponents'=>$rows]);
}
if($action==='bazaar'){
    $q=$pdo->query('SELECT id,seller_id,seller_name,item_json,price,created_at FROM bazaar_lots ORDER BY id DESC LIMIT 100');
    $rows=[]; foreach($q->fetchAll() as $r){$r['item']=json_decode($r['item_json'],true);unset($r['item_json']);$r['mine']=((string)$r['seller_id']===$uid);$rows[]=$r;}
    out(['ok'=>true,'lots'=>$rows]);
}

out(['ok'=>false,'error'=>'Unknown action'],400);
